# CTR Android — APK build and authentication/payment setup

## Build a debug APK
This repository includes `.github/workflows/build-apk.yml`. Push the project to GitHub, open **Actions → Build APK**, run the workflow (or wait for a push build), then download the `CTR-apk` artifact. The APK is at `app/build/outputs/apk/debug/app-debug.apk` inside the artifact.

## Important status
- The Android WebView app and APK build workflow are present.
- The subscription screen and Razorpay order/verification client/server code are present.
- Test-mode subscription bypass has been removed.
- Google sign-in and SMS OTP are **not yet wired to a real identity provider**. The login screen intentionally refuses to create unverified local accounts.
- Working Google sign-in, OTP, and live payments require Firebase configuration and a deployed payment server. Do not put private API keys in the Android app or `config.js`.

## Configure Firebase Authentication (Google + phone OTP)
1. Create a Firebase project in the Firebase console.
2. Add an Android app with package name `com.oneai.app`.
3. Enable **Google** and **Phone** under Authentication → Sign-in method.
4. Add SHA-1 and SHA-256 signing certificate fingerprints to Firebase app settings.
5. Download `google-services.json` into the `app/` directory and add the Google Services Gradle plugin and Firebase Authentication dependency.
6. Wire native Firebase Auth into `MainActivity` and expose only the signed-in user's Firebase ID token to the WebView.
7. Verify Firebase ID tokens on your backend. Do not trust an account ID supplied by the client. Use Firebase's phone authentication flow for OTP.
8. Test on a real Android device. Google sign-in from a `file://` WebView page is not a reliable approach; use native Android Firebase Authentication.

## Configure Razorpay
1. Deploy `server/server.js` to an HTTPS Node.js 18+ host with persistent storage for subscription data.
2. Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` as server environment variables. Keep the secret only on the server.
3. Set `window.ONEAI_CONFIG.payApi` in `app/src/main/assets/config.js` to the deployed HTTPS server base URL (no trailing slash).
4. Secure `/order`, `/verify`, `/status`, and `/ai` by requiring verified Firebase ID tokens and deriving account identity from those tokens. Add rate limits and persistent database storage before production.
5. Test with Razorpay test keys first. Never ship Razorpay secrets in the APK.

## Before publishing
Review subscription prices/terms, privacy disclosures, terms, account recovery, OTP abuse/rate limits, payment failures, subscription expiry/restore, and navigation. This starter is not production-secure until the backend verifies Firebase identity.
